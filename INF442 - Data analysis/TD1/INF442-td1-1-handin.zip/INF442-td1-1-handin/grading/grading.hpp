#ifndef TEST_HPP
#define TEST_HPP

#include <iostream>
#include <string>
#include <vector>

namespace tdgrading {
    int grading(std::ostream &out, const int test_case);
}

#endif // TEST_HPP
